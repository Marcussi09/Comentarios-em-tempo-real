# Respostas das questões

## 1. Como o Firebase identifica quem escreveu determinado comentário?

Pelo UID do usuário. Quando alguém faz login, o Firebase Authentication dá a ela um identificador único, o `uid`. No momento de comentar, o app pega o `uid` de `FirebaseAuth.instance.currentUser` e salva no documento do comentário, no campo `autorUid`, junto com o nome. Como o nome pode se repetir ou mudar, quem realmente identifica o autor é o UID. É ele também que as regras de segurança do Firestore comparam com `request.auth.uid` para saber se a pessoa pode excluir aquele comentário.

## 2. Como relacionar um comentário a uma publicação específica?

Guardando no comentário o ID da publicação. Cada publicação é um documento no Firestore e tem um ID próprio. Quando o usuário comenta, o app salva o comentário com o campo `publicacaoId` igual ao ID da publicação aberta. Para mostrar os comentários, a consulta usa `where('publicacaoId', isEqualTo: id)`, então cada discussão só traz os comentários dela e nenhum comentário aparece em outra publicação.

## 3. Por que utilizamos StreamBuilder para mostrar os comentários?

Porque o `StreamBuilder` fica ouvindo uma sequência de dados que muda ao longo do tempo e reconstrói a tela sozinho a cada novidade. O Firestore oferece isso com `snapshots()`, que manda uma lista nova sempre que um comentário é criado ou apagado. Com um `FutureBuilder` ou um `get()`, a lista seria lida uma única vez e a pessoa teria que atualizar a página para ver o que mudou.

## 4. Como garantir que os comentários apareçam automaticamente em contas diferentes?

Usando `snapshots()` do Cloud Firestore dentro de um `StreamBuilder` e salvando os comentários no banco, e não só na memória do aparelho. Quando a conta B comenta, o comentário vai para o Firestore. O Firestore avisa todos os aparelhos que estão ouvindo aquela consulta, incluindo o da conta A, que está com a discussão aberta. O `StreamBuilder` recebe a lista nova e redesenha a tela, sem precisar atualizar nada. As regras de segurança também precisam permitir que usuários logados leiam os comentários.
