# Comentários em Tempo Real

Observação: eu não tinha o código da aula do dia 19/10, então este projeto traz o aplicativo completo (cadastro, login, perfil, publicações e comentários). Se preferir continuar no seu repositório, copie para ele os arquivos de comentários:

- `lib/models/comentario.dart`
- `lib/services/comentario_service.dart`
- `lib/providers/comentario_provider.dart`
- `lib/pages/comentarios_page.dart`
- o botão de comentários que está dentro de `lib/pages/home_page.dart`
- as regras de `firestore.rules`

Como rodar:

1. `flutter create .` dentro desta pasta
2. `flutter pub get`
3. `dart pub global activate flutterfire_cli`
4. `npm install -g firebase-tools`
5. `firebase login`
6. `dart pub global run flutterfire_cli:flutterfire configure` (gera o `lib/firebase_options.dart`)
7. No console do Firebase, ative Authentication com E-mail/senha e crie o Cloud Firestore
8. Em Firestore > Regras, cole o conteúdo de `firestore.rules` e publique
9. `flutter run -d chrome`

Para o teste das duas contas, use uma janela normal e uma janela anônima do Chrome.

Estrutura no Firestore:

- `publicacoes`: `texto`, `autorNome`, `autorUid`, `criadoEm`
- `comentarios`: `texto`, `autorNome`, `autorUid`, `publicacaoId`, `criadoEm`
