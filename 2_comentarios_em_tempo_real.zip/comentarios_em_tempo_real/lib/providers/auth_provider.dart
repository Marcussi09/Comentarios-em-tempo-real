import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import '../services/auth_service.dart';

class AuthProvider extends ChangeNotifier {
  final AuthService _servico = AuthService();
  User? usuario;
  String? erro;
  bool carregando = false;

  AuthProvider() {
    _servico.mudancas().listen((novo) {
      usuario = novo;
      notifyListeners();
    });
  }

  String get nome => usuario?.displayName ?? usuario?.email ?? 'Anônimo';

  Future<void> entrar(String email, String senha) async {
    await _executar(() => _servico.entrar(email, senha));
  }

  Future<void> cadastrar(String nome, String email, String senha) async {
    if (nome.trim().isEmpty) {
      erro = 'Informe seu nome.';
      notifyListeners();
      return;
    }
    await _executar(() => _servico.cadastrar(nome, email, senha));
  }

  Future<void> sair() async {
    await _servico.sair();
  }

  void limparErro() {
    erro = null;
    notifyListeners();
  }

  Future<void> _executar(Future<void> Function() acao) async {
    carregando = true;
    erro = null;
    notifyListeners();
    try {
      await acao();
    } on FirebaseAuthException catch (e) {
      erro = e.message ?? 'Não foi possível concluir.';
    }
    carregando = false;
    notifyListeners();
  }
}
