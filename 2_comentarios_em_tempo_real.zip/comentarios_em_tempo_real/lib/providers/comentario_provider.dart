import 'package:flutter/foundation.dart';
import '../models/comentario.dart';
import '../services/comentario_service.dart';

class ComentarioProvider extends ChangeNotifier {
  final ComentarioService _servico = ComentarioService();

  Stream<List<Comentario>> acompanhar(String publicacaoId) =>
      _servico.acompanhar(publicacaoId);

  Future<void> comentar(String publicacaoId, String texto) =>
      _servico.comentar(publicacaoId, texto);

  Future<void> excluir(String comentarioId) => _servico.excluir(comentarioId);
}
