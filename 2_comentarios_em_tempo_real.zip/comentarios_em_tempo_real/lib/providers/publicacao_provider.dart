import 'package:flutter/foundation.dart';
import '../models/publicacao.dart';
import '../services/publicacao_service.dart';

class PublicacaoProvider extends ChangeNotifier {
  final PublicacaoService _servico = PublicacaoService();

  Stream<List<Publicacao>> acompanhar() => _servico.acompanhar();

  Future<void> publicar(String texto) => _servico.publicar(texto);
}
