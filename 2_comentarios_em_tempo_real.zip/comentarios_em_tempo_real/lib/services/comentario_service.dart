import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/comentario.dart';

class ComentarioService {
  final _colecao = FirebaseFirestore.instance.collection('comentarios');

  Stream<List<Comentario>> acompanhar(String publicacaoId) {
    return _colecao
        .where('publicacaoId', isEqualTo: publicacaoId)
        .snapshots()
        .map((resultado) {
      final lista = resultado.docs.map(Comentario.fromDoc).toList();
      lista.sort((a, b) => a.criadoEm.compareTo(b.criadoEm));
      return lista;
    });
  }

  Future<void> comentar(String publicacaoId, String texto) async {
    final usuario = FirebaseAuth.instance.currentUser!;
    await _colecao.add({
      'texto': texto.trim(),
      'autorNome': usuario.displayName ?? usuario.email ?? 'Anônimo',
      'autorUid': usuario.uid,
      'publicacaoId': publicacaoId,
      'criadoEm': FieldValue.serverTimestamp(),
    });
  }

  Future<void> excluir(String comentarioId) async {
    await _colecao.doc(comentarioId).delete();
  }
}
