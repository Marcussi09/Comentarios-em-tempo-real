import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/publicacao.dart';

class PublicacaoService {
  final _colecao = FirebaseFirestore.instance.collection('publicacoes');

  Stream<List<Publicacao>> acompanhar() {
    return _colecao
        .orderBy('criadoEm', descending: true)
        .snapshots()
        .map((resultado) => resultado.docs.map(Publicacao.fromDoc).toList());
  }

  Future<void> publicar(String texto) async {
    final usuario = FirebaseAuth.instance.currentUser!;
    await _colecao.add({
      'texto': texto.trim(),
      'autorNome': usuario.displayName ?? usuario.email ?? 'Anônimo',
      'autorUid': usuario.uid,
      'criadoEm': FieldValue.serverTimestamp(),
    });
  }
}
