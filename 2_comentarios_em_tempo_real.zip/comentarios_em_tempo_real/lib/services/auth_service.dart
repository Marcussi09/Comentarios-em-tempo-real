import 'package:firebase_auth/firebase_auth.dart';

class AuthService {
  final _auth = FirebaseAuth.instance;

  Stream<User?> mudancas() => _auth.userChanges();

  Future<void> entrar(String email, String senha) async {
    await _auth.signInWithEmailAndPassword(email: email.trim(), password: senha);
  }

  Future<void> cadastrar(String nome, String email, String senha) async {
    final credencial = await _auth.createUserWithEmailAndPassword(
        email: email.trim(), password: senha);
    await credencial.user!.updateDisplayName(nome.trim());
    await credencial.user!.reload();
  }

  Future<void> sair() async {
    await _auth.signOut();
  }
}
