import 'package:cloud_firestore/cloud_firestore.dart';

class Comentario {
  final String id;
  final String texto;
  final String autorNome;
  final String autorUid;
  final String publicacaoId;
  final DateTime criadoEm;

  Comentario({
    required this.id,
    required this.texto,
    required this.autorNome,
    required this.autorUid,
    required this.publicacaoId,
    required this.criadoEm,
  });

  factory Comentario.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final dados = doc.data() ?? {};
    final data = dados['criadoEm'] as Timestamp?;
    return Comentario(
      id: doc.id,
      texto: dados['texto'] ?? '',
      autorNome: dados['autorNome'] ?? 'Anônimo',
      autorUid: dados['autorUid'] ?? '',
      publicacaoId: dados['publicacaoId'] ?? '',
      criadoEm: data?.toDate() ?? DateTime.now(),
    );
  }
}
