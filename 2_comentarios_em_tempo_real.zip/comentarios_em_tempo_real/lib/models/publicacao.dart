import 'package:cloud_firestore/cloud_firestore.dart';

class Publicacao {
  final String id;
  final String texto;
  final String autorNome;
  final String autorUid;
  final DateTime criadoEm;

  Publicacao({
    required this.id,
    required this.texto,
    required this.autorNome,
    required this.autorUid,
    required this.criadoEm,
  });

  factory Publicacao.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final dados = doc.data() ?? {};
    final data = dados['criadoEm'] as Timestamp?;
    return Publicacao(
      id: doc.id,
      texto: dados['texto'] ?? '',
      autorNome: dados['autorNome'] ?? 'Anônimo',
      autorUid: dados['autorUid'] ?? '',
      criadoEm: data?.toDate() ?? DateTime.now(),
    );
  }
}
