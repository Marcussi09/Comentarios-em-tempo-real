import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/publicacao.dart';
import '../providers/auth_provider.dart';
import '../providers/publicacao_provider.dart';
import 'comentarios_page.dart';
import 'perfil_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _texto = TextEditingController();
  late final Stream<List<Publicacao>> _publicacoes;

  @override
  void initState() {
    super.initState();
    _publicacoes = context.read<PublicacaoProvider>().acompanhar();
  }

  @override
  void dispose() {
    _texto.dispose();
    super.dispose();
  }

  Future<void> _publicar() async {
    if (_texto.text.trim().isEmpty) return;
    try {
      await context.read<PublicacaoProvider>().publicar(_texto.text);
      _texto.clear();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro ao publicar: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Publicações'),
        actions: [
          IconButton(
            tooltip: 'Perfil',
            icon: const Icon(Icons.person),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const PerfilPage()),
            ),
          ),
          IconButton(
            tooltip: 'Sair',
            icon: const Icon(Icons.logout),
            onPressed: () => context.read<AuthProvider>().sair(),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _texto,
                    decoration: const InputDecoration(
                      hintText: 'Escreva uma publicação...',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                FilledButton(
                  onPressed: _publicar,
                  child: const Text('Publicar'),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Expanded(
              child: StreamBuilder<List<Publicacao>>(
                stream: _publicacoes,
                builder: (context, snapshot) {
                  if (snapshot.hasError) {
                    return Center(child: Text('Erro: ${snapshot.error}'));
                  }
                  if (!snapshot.hasData) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  final lista = snapshot.data!;
                  if (lista.isEmpty) {
                    return const Center(child: Text('Nenhuma publicação ainda.'));
                  }
                  return ListView.builder(
                    itemCount: lista.length,
                    itemBuilder: (context, indice) {
                      final publicacao = lista[indice];
                      return Card(
                        child: ListTile(
                          title: Text(publicacao.texto),
                          subtitle: Text('Por ${publicacao.autorNome}'),
                          trailing: IconButton(
                            tooltip: 'Comentários',
                            icon: const Icon(Icons.comment),
                            onPressed: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) =>
                                    ComentariosPage(publicacao: publicacao),
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
