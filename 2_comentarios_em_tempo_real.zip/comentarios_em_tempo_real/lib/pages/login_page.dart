import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _nome = TextEditingController();
  final _email = TextEditingController();
  final _senha = TextEditingController();
  bool _cadastro = false;

  @override
  void dispose() {
    _nome.dispose();
    _email.dispose();
    _senha.dispose();
    super.dispose();
  }

  void _enviar() {
    final auth = context.read<AuthProvider>();
    if (_cadastro) {
      auth.cadastrar(_nome.text, _email.text, _senha.text);
    } else {
      auth.entrar(_email.text, _senha.text);
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    return Scaffold(
      appBar: AppBar(title: Text(_cadastro ? 'Cadastro' : 'Login')),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 400),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (_cadastro) ...[
                  TextField(
                    controller: _nome,
                    decoration: const InputDecoration(
                        labelText: 'Nome', border: OutlineInputBorder()),
                  ),
                  const SizedBox(height: 12),
                ],
                TextField(
                  controller: _email,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(
                      labelText: 'E-mail', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _senha,
                  obscureText: true,
                  decoration: const InputDecoration(
                      labelText: 'Senha', border: OutlineInputBorder()),
                ),
                if (auth.erro != null) ...[
                  const SizedBox(height: 12),
                  Text(auth.erro!, style: const TextStyle(color: Colors.red)),
                ],
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: auth.carregando ? null : _enviar,
                    child: Text(_cadastro ? 'Cadastrar' : 'Entrar'),
                  ),
                ),
                TextButton(
                  onPressed: () {
                    context.read<AuthProvider>().limparErro();
                    setState(() => _cadastro = !_cadastro);
                  },
                  child: Text(_cadastro
                      ? 'Já tenho conta'
                      : 'Não tem conta? Cadastre-se'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
