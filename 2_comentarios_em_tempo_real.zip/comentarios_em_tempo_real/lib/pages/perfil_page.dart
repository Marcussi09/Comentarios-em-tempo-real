import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';

class PerfilPage extends StatelessWidget {
  const PerfilPage({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('Perfil')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Nome:', style: TextStyle(fontWeight: FontWeight.bold)),
            Text(auth.nome, style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 16),
            const Text('E-mail:', style: TextStyle(fontWeight: FontWeight.bold)),
            Text(auth.usuario?.email ?? '', style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 24),
            FilledButton(
              onPressed: () async {
                Navigator.popUntil(context, (rota) => rota.isFirst);
                await context.read<AuthProvider>().sair();
              },
              child: const Text('Sair'),
            ),
          ],
        ),
      ),
    );
  }
}
