import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/comentario.dart';
import '../models/publicacao.dart';
import '../providers/comentario_provider.dart';

class ComentariosPage extends StatefulWidget {
  final Publicacao publicacao;
  const ComentariosPage({super.key, required this.publicacao});

  @override
  State<ComentariosPage> createState() => _ComentariosPageState();
}

class _ComentariosPageState extends State<ComentariosPage> {
  final _texto = TextEditingController();
  late final Stream<List<Comentario>> _comentarios;

  @override
  void initState() {
    super.initState();
    _comentarios = context
        .read<ComentarioProvider>()
        .acompanhar(widget.publicacao.id);
  }

  @override
  void dispose() {
    _texto.dispose();
    super.dispose();
  }

  void _avisar(String mensagem) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(mensagem)),
    );
  }

  Future<void> _enviar() async {
    if (_texto.text.trim().isEmpty) return;
    try {
      await context
          .read<ComentarioProvider>()
          .comentar(widget.publicacao.id, _texto.text);
      _texto.clear();
    } catch (e) {
      if (mounted) _avisar('Erro ao comentar: $e');
    }
  }

  Future<void> _excluir(Comentario comentario) async {
    try {
      await context.read<ComentarioProvider>().excluir(comentario.id);
    } catch (e) {
      if (mounted) _avisar('Não foi possível excluir: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final meuUid = FirebaseAuth.instance.currentUser?.uid;
    final publicacao = widget.publicacao;
    return Scaffold(
      appBar: AppBar(title: const Text('Discussão')),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            color: Theme.of(context).colorScheme.surfaceContainerHighest,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(publicacao.texto, style: const TextStyle(fontSize: 18)),
                const SizedBox(height: 4),
                Text('Por ${publicacao.autorNome}'),
              ],
            ),
          ),
          const Padding(
            padding: EdgeInsets.all(12),
            child: Text('Comentários',
                style: TextStyle(fontWeight: FontWeight.bold)),
          ),
          Expanded(
            child: StreamBuilder<List<Comentario>>(
              stream: _comentarios,
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return Center(child: Text('Erro: ${snapshot.error}'));
                }
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                final lista = snapshot.data!;
                if (lista.isEmpty) {
                  return const Center(child: Text('Nenhum comentário ainda.'));
                }
                return ListView.builder(
                  itemCount: lista.length,
                  itemBuilder: (context, indice) {
                    final comentario = lista[indice];
                    return ListTile(
                      title: Text(comentario.texto),
                      subtitle: Text(comentario.autorNome),
                      trailing: comentario.autorUid == meuUid
                          ? IconButton(
                              tooltip: 'Excluir',
                              icon: const Icon(Icons.delete_outline),
                              onPressed: () => _excluir(comentario),
                            )
                          : null,
                    );
                  },
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _texto,
                    decoration: const InputDecoration(
                      hintText: 'Escreva um comentário...',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                IconButton(onPressed: _enviar, icon: const Icon(Icons.send)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
